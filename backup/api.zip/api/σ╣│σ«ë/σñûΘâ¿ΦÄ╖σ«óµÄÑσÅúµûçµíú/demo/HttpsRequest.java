import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.KeyStore;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManagerFactory;

public class HttpsRequest {
	private static String CLIENT_CERT_PWD="123456";//客户端证书密码
	private static String client_cert_path="D:/Users/zhufan408/Desktop/RLS/需求文档/14年3月需求/RLS-BIS/证书/store.jks";
	private static String TRUST_CERT_PATH="D:/Users/zhufan408/Desktop/RLS/需求文档/14年3月需求/RLS-BIS/证书/bis-stg-sdb.jks";
	private static String TRUST_CERT_PWD="123456";
	
	public static void main(String[] args) {
		sendMsgOfCert();
		//test();
//		test1();
	}
	public static String sendMsgOfCert()
	{   
		//String client_cert_path = "/wls/bis_emulator/apps/emulator/config/cert/EXV_GROUP_EAI_B2B_ZUCHE_100.jks";
		String requestData =reqXML;
		   StringBuffer sb=null;
		   try {
				SSLContext sslContext = SSLContext.getInstance("SSL"); 
				
				KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
			  	TrustManagerFactory  tmf = TrustManagerFactory .getInstance("SunX509");
			
			  	KeyStore ks = KeyStore.getInstance("JKS");
			  	ks.load(new FileInputStream(client_cert_path), CLIENT_CERT_PWD.toCharArray());
			  	kmf.init(ks, CLIENT_CERT_PWD.toCharArray());
			  	
			  	KeyStore tks = KeyStore.getInstance("JKS");
			  	tks.load(new FileInputStream(TRUST_CERT_PATH), TRUST_CERT_PWD.toCharArray());
			  	
			  	tmf.init(tks);
			  	sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
			  	
			  	HostnameVerifier hostnameVerifier = new HostnameVerifier() {
					public boolean verify(String arg0, SSLSession arg1) {
						return true;
					}
			  	};
			  	HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
			  	
//			  	URL url = new URL("https://10.36.192.51:8107");
			  	URL url = new URL("https://10.25.32.13:8007");
			  	HttpsURLConnection urlCon = (HttpsURLConnection) url.openConnection();
			  	urlCon.setDoOutput(true);
			  	urlCon.setDoInput(true);
			  	urlCon.setRequestMethod("POST");
			  	urlCon.setRequestProperty("Content-type", "text/xml;charset=GB2312");
			  	urlCon.setSSLSocketFactory(sslContext.getSocketFactory());
			  	
			  	OutputStream os = urlCon.getOutputStream();
			  	InputStream fis=new ByteArrayInputStream(requestData.getBytes());
				BufferedInputStream bis = new BufferedInputStream(fis);
				byte[] bytes = new byte[1024];
				int len = -1;
				while ((len = bis.read(bytes)) != -1) {
					os.write(bytes, 0, len);
				}
				os.flush();
				bis.close();
				fis.close();
				os.close();
				
				InputStream is = urlCon.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(is));
				sb = new StringBuffer();
				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}
				br.close();
				is.close();
				urlCon.disconnect();
			} catch (Exception e) {
               e.printStackTrace();
			}
			return null;
	   }
	public static void test()
	{
		String words="hello";
		try {
			
			FileOutputStream out = new FileOutputStream("D:/fix.sql");
			out.write(words.getBytes());
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void test1(){
		String testString="";
		testString=testString.replaceAll("\n", "<>");
		testString=testString.replaceAll("\r", "<>");
		try {
			FileInputStream fis=new FileInputStream("D:/fix.sql");
			int i=0;
			while((i=fis.read())!=-1){
				if (i==13) {
					System.out.print("回车"+(char)i);
				}else if(i==10){
					System.out.print("换行"+(char)i);
				}else {
					System.out.print((char)i);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	public static String reqXML="<?xml version=\"1.0\" encoding=\"GBK\"?>"+
//								    "<Transaction>"+
//										"<Transaction_Header>"+
//											"<exTranCode>100962</exTranCode>"+
//										"</Transaction_Header>"+
//										"<Transaction_Body>"+
//											"<isDirectForm>N</isDirectForm>"+
//											"<createSrc>2</createSrc>"+  
//											"<custSrc>2</custSrc>"+    
//											"<pageType>3</pageType>"+
//											"<name>刘文献</name>"+
//											"<sex>1</sex>"+
//											"<city>深圳</city>"+ 
//											"<email></email>"+
//											"<birthDate>1975/01/20</birthDate>"+ 
//											"<status>010101</status>"+ 
//											"<teleNum>13798902133</teleNum>"+ 
//											"<applyDate>2013-12-25 01:52:02</applyDate>"+ 
//											"<mediaSourceId>CXX-BD-13-024-badfb07f712be8c1</mediaSourceId>"+
//											"<income>7000</income>"+ 
//											"<credit>3</credit>"+ 
//											"<hasCreditCard>N</hasCreditCard>"+
//											"<creditYears>三年以下</creditYears>"+ 
//											"<loanExperience>是</loanExperience>"+ 
//											"<mortgage>Y</mortgage>"+ 
//											"<hasCarLoan>Y</hasCarLoan>"+ 
//											"<recommenderAccount>ZHUFAN408</recommenderAccount>"+ 
//											"<recommenderName>朱凡</recommenderName>"+ 
//											"<recommenderMobile>18664569510</recommenderMobile>"+ 
//											"<smsAccept>Y</smsAccept>"+ 
//											"<education></education>"+
//											"<campaignCode>123456</campaignCode>"+
//									   "</Transaction_Body>"+
//						          "</Transaction>";
	
//	public static String reqXML="<?xml version=\"1.0\" encoding=\"GBK\"?>"+
//							    "<REQUEST>"+
//									"<reqHeader>"+
//										"<exTranCode>100962</exTranCode>"+
//									"</reqHeader>"+
//									"<isDirectForm>N</isDirectForm>"+
//									"<createSrc>2</createSrc>"+  
//									"<custSrc>2</custSrc>"+    
//									"<pageType>3</pageType>"+
//									"<name>刘文献</name>"+
//									"<sex>1</sex>"+
//									"<city>深圳</city>"+ 
//									"<email></email>"+
//									"<birthDate>1975/01/20</birthDate>"+ 
//									"<status>010101</status>"+ 
//									"<teleNum>13798902133</teleNum>"+ 
//									"<applyDate>2013-12-25 01:52:02</applyDate>"+ 
//									"<mediaSourceId>CXX-BD-13-024-badfb07f712be8c1</mediaSourceId>"+
//									"<income>7000</income>"+ 
//									"<credit>3</credit>"+ 
//									"<hasCreditCard>N</hasCreditCard>"+
//									"<creditYears>三年以下</creditYears>"+ 
//									"<loanExperience>是</loanExperience>"+ 
//									"<mortgage>Y</mortgage>"+ 
//									"<hasCarLoan>Y</hasCarLoan>"+ 
//									"<recommenderAccount>ZHUFAN408</recommenderAccount>"+ 
//									"<recommenderName>朱凡</recommenderName>"+ 
//									"<recommenderMobile>18664569510</recommenderMobile>"+ 
//									"<smsAccept>Y</smsAccept>"+ 
//									"<education></education>"+
//									"<campaignCode>123456</campaignCode>"+
//							  "</REQUEST>";
	
	public static String reqXML="<?xml version=\"1.0\" encoding=\"GB2312\"?><REQUEST><reqHeader><suiteName>XQ</suiteName><exTranCode>100962</exTranCode></reqHeader><isDirectForm>N</isDirectForm><custSrc>2</custSrc><city>%e6%b7%b1%e5%9c%b3</city><name>%e5%bc%a0%e4%b8%89</name><sex>1</sex><teleNum>13714090001</teleNum><income>3000</income><mail></mail><mediaSourceId>cxx-sywl-10000</mediaSourceId><applyDate>2014-03-12 10:14:41</applyDate><campaignCode>XX_CAMP_0004</campaignCode><creditYears></creditYears><credit></credit><hasCreditCard></hasCreditCard><loanExperience></loanExperience><mortgage></mortgage><hasCarLoan></hasCarLoan><smsAccept></smsAccept><recommenderAccount></recommenderAccount><recommenderName></recommenderName><recommenderMobile></recommenderMobile><education></education><birthDate></birthDate><status>010101</status><createSrc>2</createSrc></REQUEST>";
	
}
