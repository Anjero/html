package com.yanbh.ssm.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class RequestUtil {

	public static String post(String url, Map json) {
		DefaultHttpClient httpclient = new DefaultHttpClient();
		String body = "{}";
		HttpPost post = postForm(url, json);
		body = invoke(httpclient, post);
		httpclient.getConnectionManager().shutdown();
		return body;
	}


	private static HttpPost postForm(String url, Map json) {

		HttpPost httpost = null;
		try {
			httpost = new HttpPost(url);
			if (json!=null) {
				ArrayList<BasicNameValuePair> pairs = new ArrayList<BasicNameValuePair>();
				Set<String> keys = json.keySet();  
		        for (Iterator<String> i = keys.iterator(); i.hasNext();) {  
		            String key = (String) i.next();  
		            pairs.add(new BasicNameValuePair(key, (String)json.get(key)));  
		        }  
				httpost.setEntity(new UrlEncodedFormEntity(pairs, "UTF-8"));
			}
		} catch (Exception e) {

		}
		return httpost;
	}


	private static String invoke(DefaultHttpClient httpclient,
			HttpUriRequest httpost) {

		HttpResponse response = sendRequest(httpclient, httpost);
		String body = paseResponse(response);
		return body;
	}

	private static HttpResponse sendRequest(DefaultHttpClient httpclient,
			HttpUriRequest httpost) {
		HttpResponse response = null;
		try {
			response = httpclient.execute(httpost);
		} catch (Exception e) {
		}
		return response;
	}

	private static String paseResponse(HttpResponse response) {
		HttpEntity entity = response.getEntity();
		String body = "{}";
		try {
			body = EntityUtils.toString(entity);
		} catch (Exception e) {
		}

		return body;
	}
}
