package com.yanbh.ssm.test;

import java.util.HashMap;
import java.util.Map;
import org.springframework.web.client.RestTemplate;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.yanbh.ssm.util.RequestUtil;

/***
 * 
 * @author YANBAOHANG609
 * 
 */
public class UnifyForTheCustomer {

	// token值
	private static String tokenCache = "";

	// clientId在 平安开放平台 我的应用列表里查看，格式以P_ 开头
	private static final String clientId = "P_TEST_RSP_CORE";

	// 应用密码
	private static final String clientPassword = "Hfmu196h";

	static {
		try {
			getAccessToken();// 初始化token
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 调用示例： 第一步，初始化token（在token失效期内只需获取一次，不要每次调用都获取，失效期内获取再多次也是同样的token值）
	 * 第二步，调用open api （注：如果调用结果出现token失效，那么就重新获取此token再调用。）
	 * @param args
	 * @throws JSONException
	 */
	public static void main(String[] args) throws JSONException {
		invoke();
	}

	/**
	 * 发起Open Api的调用
	 * 
	 * @return 调用返回的结果
	 */
	private static String invoke() {

		/** 拼url */
		StringBuffer url = new StringBuffer();
		url.append("http://test-api.pingan.com.cn:20080/open/appsvr/channel/rsploan/unifyForTheCustomer.do");// 其中
																												// /appsvr/group/getApproveFlow/asd是openApi的uri
		url.append("?access_token=" + tokenCache);
		url.append("&request_id=" + System.currentTimeMillis());

		Map<String, Object> paraMap = new HashMap<String, Object>();
		paraMap.put("mediaSourceId", "ZTXYD-ZTDD-001");
		paraMap.put("name", "张虎");
		paraMap.put("teleNum", "18691508082");
		paraMap.put("campaignCode", "XX_CAMP_1010WZ");
		paraMap.put("campaignName", "1010直通网站");
		paraMap.put("city", "上海市");
		paraMap.put("isDirectForm", "N");
		paraMap.put("pageType", "3");

		String result = RequestUtil.post(url.toString(), paraMap);

		paraMap = stringToMap(result);

		paraMap = (Map) getResult(paraMap);

		try {
			System.out.println(paraMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;

	}

	/**
	 * 获取access_token
	 * 
	 * @throws JSONException
	 */
	private static void getAccessToken() throws JSONException {
		RestTemplate restTemplate = new RestTemplate();
		// 拼url
		StringBuffer url = new StringBuffer();
		url.append("http://test-api.pingan.com.cn:20080/oauth/oauth2/access_token");
		url.append("?client_id=" + clientId);
		url.append("&grant_type=client_credentials");
		url.append("&client_secret=" + clientPassword);
		// 发起请求
		String tokenResult = restTemplate.getForObject(url.toString(),
				String.class);
		JSONObject result = JSONObject.parseObject(tokenResult);
		tokenCache = result.getJSONObject("data").getString("access_token");
	}

	private static Map stringToMap(String str) {
		JSONObject jsonObject = JSONObject
				.parseObject(tranString(getString(str)));
		Map map = (Map) jsonObject;
		return map;
	}

	public static String tranString(String body) {
		body = body.replaceAll("\"1.0\"", "'1.0'");
		body = body.replaceAll("\"UTF-8\"", "'UTF-8'");
		return body;
	}

	public static String getString(String relStr) {
		if (relStr != null && !relStr.trim().equals("")) {
			return relStr.replace("\"{", "{").replace("}\"", "}");
		} else {
			return "";
		}
	}

	/**
	 * 测试和生产经过openAPI封装，需要Map.get("data");
	 * 
	 * @param param
	 * @return
	 */
	private static Object getResult(Map param) {

		Object obj = param.get("data");
		if (obj instanceof Map) {
			return (Map) obj;
		} else if (obj instanceof String) {
			return (String) obj;
		} else {
			return obj;
		}
	}

}
