import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLEncoder;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;


public class TestBySSLSocket_A {
	public static void main(String[] args) {
		try {
			String data = "uid=nuoying&token=3648a2dda909b1d3ba64611a603dfd2c&product_type=2&origin=";
			data += URLEncoder.encode("大数据渠道A", "UTF-8");
			data += "&market_channel=";
			data += URLEncoder.encode("大数据渠道A", "UTF-8");
			data += "&data=";
			data += URLEncoder.encode("[{\"name\"=\"测试员\",\"phone\"=\"13800010003\",\"city\"=\"北京市\"}]", "UTF-8");
			System.out.println(data);

			URL url = new URL("https://qxy.yxapp.co/api_test/clues");
			String host = url.getHost();
			String path = url.getPath();
			int port = url.getDefaultPort();

			SSLSocket sock = (SSLSocket) (SSLSocketFactory.getDefault()).createSocket(host, port); // https

			InetAddress addr = sock.getInetAddress();
			System.out.println("host = " + host + ", path = " + path + "\n");
			System.out.println("connected " + addr + ":" + port);

			OutputStreamWriter osw = new OutputStreamWriter(sock.getOutputStream(), "utf-8");
			BufferedWriter bw = new BufferedWriter(osw);
			bw.write("POST " + path + " HTTP/1.1\r\n");
			bw.write("Host: " + host + "\r\n");
			bw.write("Content-Length: " + data.length() + "\r\n");
			bw.write("Content-Type: application/x-www-form-urlencoded\r\n");
			bw.write("\r\n");
			bw.write(data);
			bw.write("\r\n");
			bw.flush();

			InputStream in = sock.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(in, "UTF-8"));
			String line = null;
			while ((line = rd.readLine()) != null && !"0".equals(line)) {
				System.out.println(line);
			}
			rd.close();
			in.close();
			bw.close();
			sock.close();
		} catch (java.io.IOException e) {
			System.out.println(e);
		}
	}
}
