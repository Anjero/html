package com.cn.zhutong.sms;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;
import javax.rmi.CORBA.Util;

import com.cn.zhutong.util.HttpRequest;
import com.cn.zhutong.util.MD5Gen;
import com.cn.zhutong.util.TimeUtil;

public class SendSMS {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws InterruptedException{
		String url ="http://www.ztsms.cn/sendSms.do";
		String username ="";//用户名
		String password ="";密码
		String mobile ="";手机号
		String content ="";内容
		String productid ="";产品id
		String xh ="";
		try{
			content=URLEncoder.encode(content,"utf-8");
		}catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String param="url="+url+"&username="+username+"&password="+MD5Gen.getMD5(password)+"&mobile="+mobile+"&content="+content+"&productid="+productid+"&xh"+xh;
		String ret=HttpRequest.sendPost(url, param);//sendPost or sendGet
		System.out.println("ret:"+ret);
		System.out.println(param);
				
		
		
		
	}

}
