package com.cn.zhutong.sms;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;
import javax.rmi.CORBA.Util;

import com.cn.zhutong.util.HttpRequest;
import com.cn.zhutong.util.MD5Gen;
import com.cn.zhutong.util.TimeUtil;

public class SendSMS {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws InterruptedException{
		String url ="http://www.yzmsms.cn/sendSmsYZM.do";
		String username ="";
		String password ="";
		String mobile ="";
		String content ="";
		String tkey=TimeUtil.getNowTime("yyyyMMddHHmmss");
		String xh ="";
		try{
			content=URLEncoder.encode(content,"utf-8");
		}catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String param="url="+url+"&username="+username+"&password="+MD5Gen.getMD5(MD5Gen.getMD5(password)+tkey)+"&tkey="+tkey+"&mobile="+mobile+"&content="+content+"&xh"+xh;
		String ret=HttpRequest.sendPost(url, param);
		System.out.println("ret:"+ret);
		System.out.println(param);
				
		
		
		
	}

}
