using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Xml;
using System.IO;


namespace ShortMessage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strURL = "http://www.yzmsms.cn/sendSmsYZM.do?username=username&password=���ܺ�����&mobile=" + textBox1.Text + "&content=" + textBox2.Text + "&tkey=��ǰϵͳʱ��&xh=";
            WebRequest wRequest = WebRequest.Create(strURL);
            WebResponse wResponse = wRequest.GetResponse();
            Stream stream = wResponse.GetResponseStream();
            StreamReader reader = new StreamReader(stream, System.Text.Encoding.Default);
            string r = reader.ReadToEnd();
            wResponse.Close();
        }
    }
}
